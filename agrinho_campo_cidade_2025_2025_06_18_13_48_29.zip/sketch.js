let planta;
let drones = [];
let sensores = [];
let pontos = 0;
let fase = 1;
let tempo = 60; // Tempo para cada fase (em segundos)
let timer;

function setup() {
  createCanvas(800, 600);
  planta = new Planta(400, 500);
  timer = millis();
}

function draw() {
  background(200, 255, 200);  // Fundo representando um campo verde

  // Contagem regressiva para a fase
  let tempoRestante = max(0, tempo - int((millis() - timer) / 1000));
  textSize(32);
  fill(255, 0, 0);
  text('Tempo: ' + tempoRestante, 600, 50);

  // Se o tempo acabar, a fase termina
  if (tempoRestante === 0) {
    fase++;
    if (fase > 3) fase = 1;
    tempo = 60;
    timer = millis();
    pontos = 0; // Resetar pontos
  }

  // Mostrar a fase atual
  textSize(32);
  fill(0);
  text('Fase: ' + fase, 50, 50);

  // Mostrar pontos
  textSize(32);
  fill(0);
  text('Pontos: ' + pontos, 300, 50);

  // Exibir planta (se houver)
  planta.exibir();

  // Exibir drones e sensores
  for (let i = drones.length - 1; i >= 0; i--) {
    drones[i].exibir();
    if (personagemColideCom(drones[i])) {
      pontos += 10;  // Ganhar pontos
      drones.splice(i, 1);  // Remover o drone após a interação
    }
  }

  for (let i = sensores.length - 1; i >= 0; i--) {
    sensores[i].exibir();
    if (personagemColideCom(sensores[i])) {
      pontos += 5;  // Ganhar pontos
      sensores.splice(i, 1);  // Remover o sensor após a interação
    }
  }

  // A cada fase, novos drones e sensores entram em cena
  if (frameCount % 120 === 0) {
    drones.push(new Drone(random(50, 750), 0));
    sensores.push(new Sensor(random(50, 750), 0));
  }
}

// Função de colisão com drones ou sensores
function personagemColideCom(objeto) {
  let d = dist(planta.x, planta.y, objeto.x, objeto.y);
  return d < 25 + objeto.tamanho / 2;
}

class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 40;
  }

  exibir() {
    fill(34, 139, 34); // Cor da planta
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }
}

class Drone {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.velocidade = 3;
  }

  exibir() {
    fill(255, 223, 0);  // Cor do drone
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
    this.y += this.velocidade;  // O drone sobe pela tela
  }
}

class Sensor {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 15;
    this.velocidade = 2;
  }

  exibir() {
    fill(0, 255, 255);  // Cor do sensor
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
    this.y += this.velocidade;  // O sensor desce pela tela
  }
}

function keyPressed() {
  // Controlar a planta (personagem)
  if (keyCode === LEFT_ARROW) {
    planta.x -= 20;
  } else if (keyCode === RIGHT_ARROW) {
    planta.x += 20;
  }
}